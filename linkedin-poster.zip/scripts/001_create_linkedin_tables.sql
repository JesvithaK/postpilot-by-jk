-- LinkedIn OAuth tokens
create table if not exists public.linkedin_tokens (
  user_id uuid primary key references auth.users(id) on delete cascade,
  access_token text not null,
  refresh_token text,
  expires_at timestamptz,
  linkedin_member_urn text not null, -- e.g. 'urn:li:person:abc'
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.linkedin_tokens enable row level security;

create policy "Users can manage their own linkedin token"
on public.linkedin_tokens
for all
to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

-- Scheduled posts
create table if not exists public.scheduled_posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  content text not null,
  scheduled_at timestamptz not null,
  status text not null default 'pending', -- pending | posted | failed | cancelled
  error text,
  created_at timestamptz not null default now(),
  posted_at timestamptz
);

alter table public.scheduled_posts enable row level security;

create policy "Users can read their scheduled posts"
on public.scheduled_posts
for select
to authenticated
using (auth.uid() = user_id);

create policy "Users can insert their scheduled posts"
on public.scheduled_posts
for insert
to authenticated
with check (auth.uid() = user_id);

create policy "Users can update their scheduled posts"
on public.scheduled_posts
for update
to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);
