-- Create minimal storage with RLS. Run this script from the scripts tab.
create table if not exists public.linkedin_accounts (
  user_id uuid primary key references auth.users(id) on delete cascade,
  access_token text not null,
  expires_at timestamptz not null,
  member_id text not null,
  member_urn text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.linkedin_accounts enable row level security;

create policy "own row" on public.linkedin_accounts
  for all
  using (auth.uid() = user_id)
  with check (auth.uid() = user_id);

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists linkedin_accounts_set_updated_at on public.linkedin_accounts;

create trigger linkedin_accounts_set_updated_at
before update on public.linkedin_accounts
for each row execute procedure public.set_updated_at();
