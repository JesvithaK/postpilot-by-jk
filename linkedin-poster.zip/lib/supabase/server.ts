import { cookies, headers } from "next/headers"
import { createServerClient } from "@supabase/ssr"

let supabaseServerClient: ReturnType<typeof createServerClient> | null = null

export function getSupabaseServer() {
  if (!supabaseServerClient) {
    supabaseServerClient = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          get(name: string) {
            return cookies().get(name)?.value
          },
          set(name: string, value: string, options: any) {
            try {
              cookies().set({ name, value, ...options })
            } catch {}
          },
          remove(name: string, options: any) {
            try {
              cookies().set({ name, value: "", ...options })
            } catch {}
          },
        },
        headers: {
          get(key: string) {
            return headers().get(key) ?? undefined
          },
        },
      },
    )
  }
  return supabaseServerClient
}
