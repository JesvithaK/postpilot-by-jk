import { createClient } from "@supabase/supabase-js"

let supabaseServiceSingleton: ReturnType<typeof createClient> | null = null

export function getSupabaseService() {
  if (supabaseServiceSingleton) return supabaseServiceSingleton
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL!
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY!
  supabaseServiceSingleton = createClient(url, key, { auth: { persistSession: false } })
  return supabaseServiceSingleton
}
