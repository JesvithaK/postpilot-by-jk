import { getSupabaseServer } from "@/lib/supabase/server"

const LINKEDIN_AUTH = "https://www.linkedin.com/oauth/v2/authorization"
const LINKEDIN_TOKEN = "https://www.linkedin.com/oauth/v2/accessToken"
const LINKEDIN_ME = "https://api.linkedin.com/v2/me"
// Newer Posts API (recommended). If unavailable, fall back to ugcPosts.
const LINKEDIN_POSTS = "https://api.linkedin.com/rest/posts"
const LINKEDIN_UGC = "https://api.linkedin.com/v2/ugcPosts"
const LINKEDIN_EMAIL = "https://api.linkedin.com/v2/emailAddress?q=members&projection=(elements*(handle~))"

const LINKEDIN_API_VERSION = process.env.LINKEDIN_VERSION || "202410"

export function getLinkedInAuthUrl(state: string, origin?: string) {
  const clientId = process.env.LINKEDIN_CLIENT_ID
  const redirectUri = process.env.LINKEDIN_REDIRECT_URI || (origin ? `${origin}/auth/linkedin/callback` : undefined)

  if (!clientId) {
    throw new Error("Missing LINKEDIN_CLIENT_ID")
  }
  if (!redirectUri) {
    throw new Error("Missing LINKEDIN_REDIRECT_URI and no origin provided")
  }

  const params = new URLSearchParams({
    response_type: "code",
    client_id: clientId,
    redirect_uri: redirectUri,
    scope: ["w_member_social", "r_liteprofile", "r_emailaddress"].join(" "),
    state,
  })
  return `${LINKEDIN_AUTH}?${params.toString()}`
}

export async function exchangeCodeForToken(code: string, origin?: string) {
  const clientId = process.env.LINKEDIN_CLIENT_ID
  const clientSecret = process.env.LINKEDIN_CLIENT_SECRET
  const redirectUri = process.env.LINKEDIN_REDIRECT_URI || (origin ? `${origin}/auth/linkedin/callback` : undefined)

  if (!clientId) throw new Error("Missing LINKEDIN_CLIENT_ID")
  if (!clientSecret) throw new Error("Missing LINKEDIN_CLIENT_SECRET")
  if (!redirectUri) throw new Error("Missing LINKEDIN_REDIRECT_URI and no origin provided")

  const body = new URLSearchParams({
    grant_type: "authorization_code",
    code,
    redirect_uri: redirectUri,
    client_id: clientId,
    client_secret: clientSecret,
  })
  const res = await fetch(LINKEDIN_TOKEN, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body,
  })
  if (!res.ok) {
    throw new Error(`Token exchange failed: ${res.status} ${await res.text()}`)
  }
  return (await res.json()) as {
    access_token: string
    expires_in: number
    refresh_token?: string
    refresh_token_expires_in?: number
  }
}

export async function refreshLinkedInToken(refreshToken: string) {
  const body = new URLSearchParams({
    grant_type: "refresh_token",
    refresh_token: refreshToken,
    client_id: process.env.LINKEDIN_CLIENT_ID!,
    client_secret: process.env.LINKEDIN_CLIENT_SECRET!,
  })
  const res = await fetch(LINKEDIN_TOKEN, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body,
  })
  if (!res.ok) {
    throw new Error(`Token refresh failed: ${res.status} ${await res.text()}`)
  }
  return (await res.json()) as {
    access_token: string
    expires_in: number
    refresh_token?: string
    refresh_token_expires_in?: number
  }
}

export async function getMemberUrn(accessToken: string) {
  const res = await fetch(LINKEDIN_ME, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "X-Restli-Protocol-Version": "2.0.0",
      "LinkedIn-Version": LINKEDIN_API_VERSION, // critical for v2/me
      Accept: "application/json",
    },
    cache: "no-store",
  })
  if (!res.ok) {
    throw new Error(`Failed to fetch member profile: ${res.status} ${await res.text()}`)
  }
  const data = await res.json()
  const id = data?.id
  if (!id) throw new Error("No member id in response")
  return `urn:li:person:${id}`
}

export async function getMemberEmail(accessToken: string): Promise<string | null> {
  const res = await fetch(LINKEDIN_EMAIL, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "X-Restli-Protocol-Version": "2.0.0",
      "LinkedIn-Version": LINKEDIN_API_VERSION,
      Accept: "application/json",
    },
    cache: "no-store",
  })

  if (!res.ok) {
    // If your app isn't approved for r_emailaddress yet, return null gracefully.
    // Useful during review: don't break the whole flow.
    try {
      const txt = await res.text()
      console.log("[v0] LinkedIn email fetch not available:", res.status, txt)
    } catch (_) {}
    return null
  }

  const data = await res.json().catch(() => null as any)
  const email = data?.elements?.[0]?.["handle~"]?.emailAddress ?? null
  return typeof email === "string" ? email : null
}

export async function ensureFreshAccessToken(userId: string) {
  const supabase = getSupabaseServer()
  const { data: tok } = await supabase.from("linkedin_tokens").select("*").eq("user_id", userId).maybeSingle()

  if (!tok) throw new Error("LinkedIn not connected")

  const now = new Date()
  const expires = tok.expires_at ? new Date(tok.expires_at) : null
  if (expires && expires > now) {
    return { accessToken: tok.access_token, memberUrn: tok.linkedin_member_urn }
  }

  if (!tok.refresh_token) {
    // no refresh token; try using existing (may fail) or require reconnect
    return { accessToken: tok.access_token, memberUrn: tok.linkedin_member_urn }
  }

  const refreshed = await refreshLinkedInToken(tok.refresh_token)
  const newExpires = new Date(Date.now() + refreshed.expires_in * 1000)
  const { error } = await supabase
    .from("linkedin_tokens")
    .update({
      access_token: refreshed.access_token,
      refresh_token: refreshed.refresh_token ?? tok.refresh_token,
      expires_at: newExpires.toISOString(),
      updated_at: new Date().toISOString(),
    })
    .eq("user_id", userId)

  if (error) throw error

  return { accessToken: refreshed.access_token, memberUrn: tok.linkedin_member_urn }
}

export async function createTextPost({
  accessToken,
  authorUrn,
  text,
}: {
  accessToken: string
  authorUrn: string
  text: string
}) {
  // Try Posts API first
  const postsRes = await fetch(LINKEDIN_POSTS, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
      "X-Restli-Protocol-Version": "2.0.0",
      "LinkedIn-Version": LINKEDIN_API_VERSION,
      Accept: "application/json",
    },
    body: JSON.stringify({
      author: authorUrn,
      commentary: text,
      visibility: "PUBLIC",
      distribution: { feedDistribution: "MAIN_FEED", targetEntities: [], thirdPartyDistributionChannels: [] },
      lifecycleState: "PUBLISHED",
      isReshareDisabledByAuthor: false,
    }),
  })

  if (postsRes.ok) {
    return { ok: true, api: "posts", result: await postsRes.json() }
  }

  // Fallback to UGC Posts if Posts API is not enabled
  const ugcRes = await fetch(LINKEDIN_UGC, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
      "X-Restli-Protocol-Version": "2.0.0",
      "LinkedIn-Version": LINKEDIN_API_VERSION,
      Accept: "application/json",
    },
    body: JSON.stringify({
      author: authorUrn,
      lifecycleState: "PUBLISHED",
      specificContent: {
        "com.linkedin.ugc.ShareContent": {
          shareCommentary: { text },
          shareMediaCategory: "NONE",
        },
      },
      visibility: { "com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC" },
    }),
  })

  if (!ugcRes.ok) {
    const errText = await ugcRes.text()
    throw new Error(`LinkedIn post failed: ${ugcRes.status} ${errText}`)
  }
  return { ok: true, api: "ugc", result: await ugcRes.json() }
}

export async function createLinkedInPost({
  accessToken,
  authorUrn,
  commentary,
  text,
}: {
  accessToken: string
  authorUrn: string
  commentary?: string
  text?: string
}) {
  const content = (commentary ?? text ?? "").trim()
  if (!content) {
    throw new Error("Missing post content")
  }
  return createTextPost({ accessToken, authorUrn, text: content })
}
