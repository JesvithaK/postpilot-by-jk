"use client"

import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"

export function LinkedInConnect() {
  function start() {
    window.location.href = "/auth/linkedin/start"
  }
  return (
    <section
      aria-labelledby="connect-heading"
      className="max-w-sm w-full rounded-xl p-5 bg-black border border-zinc-800 shadow-sm"
    >
      <h2 id="connect-heading" className="text-xl font-semibold mb-2 text-white text-balance">
        Connect LinkedIn
      </h2>
      <p className="text-sm text-zinc-400 mb-4">Link your LinkedIn account to publish posts from your prompts.</p>

      <ul className="text-sm text-zinc-300 mb-5 grid gap-2">
        <li className="flex items-center gap-2">
          <Check className="h-4 w-4 text-cyan-400" aria-hidden="true" />
          Secure OAuth — you’re always in control
        </li>
        <li className="flex items-center gap-2">
          <Check className="h-4 w-4 text-cyan-400" aria-hidden="true" />
          Post now or schedule for later
        </li>
        <li className="flex items-center gap-2">
          <Check className="h-4 w-4 text-cyan-400" aria-hidden="true" />
          Edit AI drafts before posting
        </li>
      </ul>

      <Button
        onClick={start}
        className="w-full bg-cyan-500 text-black hover:bg-cyan-400"
        aria-label="Connect your LinkedIn account"
      >
        Connect LinkedIn
      </Button>

      <p className="mt-3 text-[13px] leading-5 text-zinc-500">
        Redirect URL configured:{" "}
        <span className="text-zinc-300 break-all">https://postpilot-by-jk.vercel.app/auth/linkedin/callback</span>
      </p>
    </section>
  )
}
