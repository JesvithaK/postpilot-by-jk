"use client"

import type React from "react"

import { useState } from "react"
import { getSupabaseBrowser } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { useRouter } from "next/navigation"

export function LoginPanel() {
  const supabase = getSupabaseBrowser()
  const router = useRouter()
  const [mode, setMode] = useState<"signin" | "signup">("signin")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError(null)
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL || window.location.origin,
          },
        })
        if (error) throw error
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password })
        if (error) throw error
      }
      router.refresh()
    } catch (err: any) {
      setError(err?.message || "Auth failed")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-sm w-full border rounded-lg p-4">
      <h2 className="text-lg font-semibold text-balance mb-2">{mode === "signin" ? "Sign in" : "Create an account"}</h2>
      <form onSubmit={handleSubmit} className="grid gap-3">
        <div className="grid gap-1">
          <Label htmlFor="email">Email</Label>
          <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
        </div>
        <div className="grid gap-1">
          <Label htmlFor="password">Password</Label>
          <Input
            id="password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        {error && <p className="text-sm text-red-600">{error}</p>}
        <Button type="submit" disabled={loading}>
          {loading ? "..." : mode === "signin" ? "Sign in" : "Sign up"}
        </Button>
      </form>
      <div className="text-sm mt-3">
        {mode === "signin" ? (
          <button className="underline" onClick={() => setMode("signup")}>
            Need an account? Sign up
          </button>
        ) : (
          <button className="underline" onClick={() => setMode("signin")}>
            Have an account? Sign in
          </button>
        )}
      </div>
    </div>
  )
}
