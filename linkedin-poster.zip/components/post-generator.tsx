"use client"

import { useState } from "react"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

type Generated = { text: string }

export function PostGenerator() {
  const [prompt, setPrompt] = useState("")
  const [draft, setDraft] = useState<Generated | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [accepted, setAccepted] = useState(false)
  const [schedule, setSchedule] = useState<"now" | "later" | null>(null)
  const [datetime, setDatetime] = useState<string>("")

  const disabled = loading

  async function generate() {
    setLoading(true)
    setError(null)
    setDraft(null)
    setAccepted(false)
    setSchedule(null)
    try {
      const res = await fetch("/api/ai/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt }),
      })
      if (!res.ok) throw new Error(await res.text())
      const data = await res.json()
      setDraft({ text: data.text })
    } catch (e: any) {
      setError(e.message || "Failed to generate")
    } finally {
      setLoading(false)
    }
  }

  async function postNow() {
    setLoading(true)
    setError(null)
    try {
      const res = await fetch("/api/linkedin/post", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: draft?.text, mode: "now" }),
      })
      if (!res.ok) throw new Error(await res.text())
      setSchedule("now")
      alert("Posted to LinkedIn!")
      setDraft(null)
    } catch (e: any) {
      setError(e.message || "Post failed")
    } finally {
      setLoading(false)
    }
  }

  async function schedulePost() {
    if (!datetime) {
      setError("Please choose a date & time")
      return
    }
    setLoading(true)
    setError(null)
    try {
      const res = await fetch("/api/linkedin/post", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: draft?.text, mode: "schedule", scheduledAt: datetime }),
      })
      if (!res.ok) throw new Error(await res.text())
      setSchedule("later")
      alert("Scheduled!")
      setDraft(null)
      setAccepted(false)
      setDatetime("")
    } catch (e: any) {
      setError(e.message || "Schedule failed")
    } finally {
      setLoading(false)
    }
  }

  const charCount = prompt.trim().length

  return (
    <section
      aria-labelledby="generator-heading"
      className="max-w-xl w-full rounded-xl p-5 bg-black border border-zinc-800 shadow-sm grid gap-5"
    >
      <header className="flex items-start justify-between">
        <div>
          <h2 id="generator-heading" className="text-xl font-semibold text-white text-balance">
            AI Post Generator
          </h2>
          <p className="text-sm text-zinc-400 mt-1">
            Write a prompt. Review the draft. Post now or schedule for later.
          </p>
        </div>
        <span className="text-xs text-zinc-500">{charCount} chars</span>
      </header>

      <div className="grid gap-2">
        <Label htmlFor="prompt" className="text-sm text-zinc-300">
          Prompt
        </Label>
        <Textarea
          id="prompt"
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="e.g. Announce our new AI post generator, friendly tone, add a question at the end."
          className="bg-zinc-950 border-zinc-800 text-zinc-100 placeholder:text-zinc-500 min-h-28"
        />
      </div>

      <div className="flex items-center gap-2">
        <Button
          onClick={generate}
          disabled={disabled || !prompt.trim()}
          className="bg-cyan-500 text-black hover:bg-cyan-400"
        >
          {loading ? "Generating..." : "Generate"}
        </Button>
        <Button
          variant="secondary"
          onClick={() => {
            setDraft(null)
            setAccepted(false)
            setSchedule(null)
            setError(null)
            setPrompt("")
          }}
          className="bg-zinc-800 text-zinc-200 hover:bg-zinc-700"
        >
          Reset
        </Button>
      </div>

      {error && <p className="text-sm text-red-400">{error}</p>}

      {draft && !accepted && (
        <div className="grid gap-3 border border-zinc-800 rounded-lg p-4 bg-zinc-950">
          <h3 className="font-medium text-white">Draft</h3>
          <div className="text-sm whitespace-pre-wrap text-zinc-200">{draft.text}</div>
          <div className="flex gap-2">
            <Button onClick={() => setAccepted(true)} className="bg-cyan-500 text-black hover:bg-cyan-400">
              Accept
            </Button>
            <Button
              variant="destructive"
              onClick={() => setDraft(null)}
              className="bg-zinc-800 text-zinc-200 hover:bg-zinc-700"
            >
              Reject
            </Button>
          </div>
        </div>
      )}

      {draft && accepted && schedule === null && (
        <div className="grid gap-3 border border-zinc-800 rounded-lg p-4 bg-zinc-950">
          <h3 className="font-medium text-white">Post now or schedule?</h3>
          <div className="flex gap-2">
            <Button onClick={postNow} disabled={disabled} className="bg-cyan-500 text-black hover:bg-cyan-400">
              Post now
            </Button>
            <Button
              variant="secondary"
              onClick={() => setSchedule("later")}
              className="bg-zinc-800 text-zinc-200 hover:bg-zinc-700"
            >
              Schedule
            </Button>
          </div>
        </div>
      )}

      {draft && accepted && schedule === "later" && (
        <div className="grid gap-3 border border-zinc-800 rounded-lg p-4 bg-zinc-950">
          <div className="grid gap-2">
            <Label htmlFor="dt" className="text-sm text-zinc-300">
              Choose date & time
            </Label>
            <Input
              id="dt"
              type="datetime-local"
              value={datetime}
              onChange={(e) => setDatetime(e.target.value)}
              className="bg-zinc-950 border-zinc-800 text-zinc-100 placeholder:text-zinc-500"
            />
          </div>
          <div className="flex gap-2">
            <Button onClick={schedulePost} disabled={disabled} className="bg-cyan-500 text-black hover:bg-cyan-400">
              Confirm schedule
            </Button>
            <Button
              variant="secondary"
              onClick={() => setSchedule(null)}
              className="bg-zinc-800 text-zinc-200 hover:bg-zinc-700"
            >
              Back
            </Button>
          </div>
          <p className="text-xs text-zinc-500">We’ll publish at your local time.</p>
        </div>
      )}
    </section>
  )
}
