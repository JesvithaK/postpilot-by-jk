import { NextResponse } from "next/server"
import { cookies } from "next/headers"
import { exchangeCodeForToken, getMemberUrn, getMemberEmail } from "@/lib/linkedin"
import { getSupabaseServer } from "@/lib/supabase/server"

export async function GET(request: Request) {
  const url = new URL(request.url)
  const origin = url.origin
  const code = url.searchParams.get("code")
  const state = url.searchParams.get("state")
  const cookieStore = cookies()
  const stateCookie = cookieStore.get("li_oauth_state")?.value

  if (!code) {
    return NextResponse.redirect(`${origin}/?li_error=missing_code`)
  }
  if (!state || !stateCookie || state !== stateCookie) {
    return NextResponse.redirect(`${origin}/?li_error=invalid_state`)
  }

  // clear state cookie
  const redirectHome = (qs: string) => {
    const res = NextResponse.redirect(`${origin}/${qs}`)
    // expire the cookie
    res.cookies.set("li_oauth_state", "", { path: "/", maxAge: 0 })
    return res
  }

  try {
    const token = await exchangeCodeForToken(code, origin)

    const supabase = getSupabaseServer()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return redirectHome("?li_error=not_logged_in")
    }

    // Fetch member urn; lib ensures LinkedIn-Version header
    const memberUrn = await getMemberUrn(token.access_token)

    try {
      const _email = await getMemberEmail(token.access_token)
      // Optionally persist _email where you want; currently not stored to avoid schema assumptions.
      // console.log("[v0] LinkedIn member email:", _email)
    } catch (_) {
      // swallow email fetch issues to avoid breaking OAuth
    }

    // store/refresh tokens
    const expiresAt = new Date(Date.now() + token.expires_in * 1000).toISOString()
    const { error } = await supabase.from("linkedin_tokens").upsert(
      {
        user_id: user.id,
        access_token: token.access_token,
        refresh_token: token.refresh_token ?? null,
        expires_at: expiresAt,
        linkedin_member_urn: memberUrn,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "user_id" },
    )

    if (error) {
      return redirectHome(`?li_error=db_upsert_failed`)
    }

    return redirectHome("?li_connected=1")
  } catch (e: any) {
    // surface a concise error
    return redirectHome(`?li_error=oauth_failed`)
  }
}
