import { NextResponse } from "next/server"
import crypto from "node:crypto"
import { getLinkedInAuthUrl } from "@/lib/linkedin"

export async function GET(request: Request) {
  const origin = new URL(request.url).origin
  const state = crypto.randomUUID()
  const authUrl = getLinkedInAuthUrl(state, origin)

  const res = NextResponse.redirect(authUrl)
  // ensure cookie is sent on callback path (/auth/...) as well as /api routes
  res.cookies.set("li_oauth_state", state, {
    httpOnly: true,
    sameSite: "lax",
    secure: true,
    path: "/", // critical to avoid "invalid state"
  })
  return res
}
