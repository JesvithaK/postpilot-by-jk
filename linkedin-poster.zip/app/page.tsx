import { getSupabaseServer } from "@/lib/supabase/server"
import { LoginPanel } from "@/components/login-panel"
import { LinkedInConnect } from "@/components/linkedin-connect"
import { PostGenerator } from "@/components/post-generator"

export default async function Page() {
  const supabase = getSupabaseServer()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  return (
    <main className="mx-auto max-w-3xl p-6 grid gap-6">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-balance text-foreground">Postpilot by jk</h1>
          <p className="text-sm text-muted-foreground">
            Generate, review, and publish LinkedIn posts. Connect your account, then create or schedule.
          </p>
        </div>
        <AuthStatus />
      </header>
      {!user ? (
        <div className="flex justify-center">
          <LoginPanel />
        </div>
      ) : (
        <LinkedInOrGenerator userId={user.id} />
      )}
    </main>
  )
}

async function LinkedInOrGenerator({ userId }: { userId: string }) {
  const supabase = getSupabaseServer()
  const { data: token } = await supabase.from("linkedin_tokens").select("user_id").eq("user_id", userId).maybeSingle()

  if (!token) {
    return (
      <div className="flex justify-center">
        <LinkedInConnect />
      </div>
    )
  }
  return <PostGenerator />
}

async function AuthStatus() {
  const supabase = getSupabaseServer()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) return null
  async function signOut() {
    "use server"
    const supabase = getSupabaseServer()
    await supabase.auth.signOut()
  }
  return (
    <form action={signOut}>
      <button className="text-sm underline">Sign out</button>
    </form>
  )
}
