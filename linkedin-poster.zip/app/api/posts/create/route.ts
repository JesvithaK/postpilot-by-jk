import { NextResponse } from "next/server"
import { getSupabaseServer } from "@/lib/supabase/server"
import { createLinkedInPost } from "@/lib/linkedin"

export async function POST(req: Request) {
  const supabase = getSupabaseServer()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const { content } = await req.json().catch(() => ({ content: "" }))
  if (!content || typeof content !== "string") {
    return NextResponse.json({ error: "Missing content" }, { status: 400 })
  }

  const { data: token } = await supabase.from("linkedin_tokens").select("*").eq("user_id", user.id).maybeSingle()
  if (!token) return NextResponse.json({ error: "LinkedIn not connected" }, { status: 400 })

  try {
    const result = await createLinkedInPost({
      accessToken: token.access_token as string,
      authorUrn: token.member_urn as string,
      commentary: content,
    })
    return NextResponse.json({ ok: true, result })
  } catch (e: any) {
    return NextResponse.json({ error: e.message || "LinkedIn post failed" }, { status: 500 })
  }
}
