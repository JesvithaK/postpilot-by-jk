import { type NextRequest, NextResponse } from "next/server"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

export async function POST(req: NextRequest) {
  const { prompt } = await req.json()
  if (!prompt || typeof prompt !== "string") {
    return new NextResponse("Missing prompt", { status: 400 })
  }

  const system =
    "You write concise, engaging, professional LinkedIn posts. Use a friendly, helpful tone, short paragraphs, and 1-3 relevant hashtags. Avoid emojis unless clearly appropriate."

  const { text } = await generateText({
    model: openai("gpt-4o-mini"),
    system,
    prompt: `Create a LinkedIn post based on this prompt:\n\n${prompt}\n\nKeep it under 1200 characters.`,
  })

  return NextResponse.json({ text })
}
