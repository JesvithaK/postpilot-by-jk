import { NextResponse } from "next/server"
import { getSupabaseServer } from "@/lib/supabase/server"

export async function POST(req: Request) {
  const supabase = getSupabaseServer()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const { content, scheduledAt } = await req.json().catch(() => ({}))
  if (!content || !scheduledAt) {
    return NextResponse.json({ error: "Missing content or scheduledAt" }, { status: 400 })
  }

  const { data, error } = await supabase
    .from("scheduled_posts")
    .insert({ user_id: user.id, content, scheduled_at: scheduledAt })
    .select()
    .single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json({ ok: true, post: data })
}
