import { type NextRequest, NextResponse } from "next/server"
import { getRedis } from "@/lib/upstash"
import { getSupabaseServer } from "@/lib/supabase/server"
import { ensureFreshAccessToken, createTextPost } from "@/lib/linkedin"

export const dynamic = "force-dynamic"

export async function GET(_req: NextRequest) {
  const redis = getRedis()
  const key = "scheduled:linkedin:posts"
  const now = Date.now()

  // Fetch due jobs
  const due = await redis.zrangebyscore(key, 0, now)
  const supabase = getSupabaseServer()

  let processed = 0
  for (const raw of due) {
    try {
      const job = JSON.parse(raw) as { id: string; userId: string }
      // Remove job from queue first to avoid duplicates
      await redis.zrem(key, raw)

      // Load post row
      const { data: row, error } = await supabase
        .from("scheduled_posts")
        .select("id, user_id, content, status")
        .eq("id", job.id)
        .maybeSingle()
      if (error || !row) continue
      if (row.status !== "pending") continue

      // Get token and post
      const { accessToken, memberUrn } = await ensureFreshAccessToken(job.userId)
      await createTextPost({ accessToken, authorUrn: memberUrn, text: row.content })

      await supabase
        .from("scheduled_posts")
        .update({ status: "posted", posted_at: new Date().toISOString() })
        .eq("id", job.id)

      processed++
    } catch (e: any) {
      // Best-effort: mark failed if we know the id
      try {
        const maybe = JSON.parse(e?.message ?? "{}")
        void maybe
      } catch {}
    }
  }

  return NextResponse.json({ ok: true, processed })
}
