import { type NextRequest, NextResponse } from "next/server"

export async function GET(req: NextRequest) {
  const origin = req.nextUrl.origin
  return NextResponse.redirect(`${origin}/auth/linkedin/start`)
}

function buildAuthorizeUrl(origin: string) {
  const clientId = process.env.LINKEDIN_CLIENT_ID
  const fallbackRedirect = `${origin}/api/linkedin/callback`
  const redirectUri = process.env.LINKEDIN_REDIRECT_URI || fallbackRedirect

  if (!clientId) {
    throw new Error("Missing LINKEDIN_CLIENT_ID")
  }
  if (!redirectUri) {
    throw new Error("Missing LINKEDIN_REDIRECT_URI")
  }

  // LinkedIn 3-legged OAuth 2.0
  const base = "https://www.linkedin.com/oauth/v2/authorization"
  const params = new URLSearchParams({
    response_type: "code",
    client_id: clientId,
    redirect_uri: redirectUri,
    // Minimal set for posting + basic profile. Avoid offline_access (limited partners).
    scope: "w_member_social r_liteprofile",
    // state will be added below
  })

  return { base, params, redirectUri }
}
