import { NextResponse } from "next/server"
import { cookies } from "next/headers"
import { getSupabaseServer } from "@/lib/supabase/server"
import { getMemberUrn } from "@/lib/linkedin"

export async function GET(request: Request) {
  const url = new URL(request.url)
  const code = url.searchParams.get("code")
  const state = url.searchParams.get("state")
  const storedState = cookies().get("li_oauth_state")?.value
  if (!code || !state || !storedState || state !== storedState) {
    return NextResponse.redirect(new URL("/?error=oauth_state", request.url))
  }

  const clientId = process.env.LINKEDIN_CLIENT_ID!
  const clientSecret = process.env.LINKEDIN_CLIENT_SECRET!
  const redirectUri = process.env.LINKEDIN_REDIRECT_URI || `${url.origin}/api/linkedin/callback`

  const tokenRes = await fetch("https://www.linkedin.com/oauth/v2/accessToken", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "authorization_code",
      code,
      redirect_uri: redirectUri,
      client_id: clientId,
      client_secret: clientSecret,
    }),
  })
  if (!tokenRes.ok) {
    const err = await tokenRes.text()
    return NextResponse.redirect(new URL(`/??error=token&detail=${encodeURIComponent(err)}`, request.url))
  }
  const tokenData: any = await tokenRes.json()
  const accessToken = tokenData.access_token as string
  const expiresInSec = Number(tokenData.expires_in ?? 0)
  const expiresAt = new Date(Date.now() + expiresInSec * 1000).toISOString()

  const memberUrn = await getMemberUrn(accessToken)

  const supabase = getSupabaseServer()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) return NextResponse.redirect(new URL("/?error=auth", request.url))

  const { error } = await supabase
    .from("linkedin_tokens")
    .upsert({ user_id: user.id, access_token: accessToken, expires_at: expiresAt, member_urn: memberUrn })
    .select()
    .single()

  if (error) {
    return NextResponse.redirect(new URL(`/??error=db`, request.url))
  }

  cookies().delete("li_oauth_state")
  return NextResponse.redirect(new URL("/", request.url))
}
