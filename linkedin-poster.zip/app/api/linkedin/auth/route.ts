import { NextResponse } from "next/server"
import { getSupabaseServer } from "@/lib/supabase/server"

export async function GET(request: Request) {
  const supabase = getSupabaseServer()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) return NextResponse.redirect(new URL("/", request.url))

  const origin = new URL(request.url).origin
  // Always initiate OAuth via /auth/linkedin/start which uses scopes: w_member_social r_liteprofile
  return NextResponse.redirect(`${origin}/auth/linkedin/start`)
}
