import { NextResponse } from "next/server"
import { getLinkedInAuthUrl } from "@/lib/linkedin"
import crypto from "crypto"

export async function GET(request: Request) {
  const missing: string[] = []
  if (!process.env.LINKEDIN_CLIENT_ID) missing.push("LINKEDIN_CLIENT_ID")
  if (!process.env.LINKEDIN_CLIENT_SECRET) missing.push("LINKEDIN_CLIENT_SECRET")

  if (missing.length) {
    const url = new URL("/", request.url)
    url.searchParams.set("error", "linkedin_env")
    url.searchParams.set("missing", missing.join(","))
    return NextResponse.redirect(url)
  }

  try {
    const state = crypto.randomUUID()
    const origin = new URL(request.url).origin
    const url = getLinkedInAuthUrl(state, origin)
    const res = NextResponse.redirect(url)
    res.cookies.set("li_oauth_state", state, {
      httpOnly: true,
      path: "/",
      sameSite: "lax",
      secure: true,
      maxAge: 600,
    })
    return res
  } catch (err) {
    const url = new URL("/", request.url)
    url.searchParams.set("error", "linkedin_oauth_init")
    url.searchParams.set("detail", "init_failed")
    return NextResponse.redirect(url)
  }
}
