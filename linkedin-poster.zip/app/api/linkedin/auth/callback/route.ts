import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const url = new URL(request.url)
  const origin = url.origin
  const qs = url.searchParams.toString()
  return NextResponse.redirect(`${origin}/auth/linkedin/callback${qs ? `?${qs}` : ""}`)
}

// ... existing code here ...
