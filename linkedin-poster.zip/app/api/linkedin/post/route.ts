import { type NextRequest, NextResponse } from "next/server"
import { getSupabaseServer } from "@/lib/supabase/server"
import { ensureFreshAccessToken, createTextPost } from "@/lib/linkedin"
import { getRedis } from "@/lib/upstash"

export async function POST(req: NextRequest) {
  const supabase = getSupabaseServer()
  const {
    data: { user },
  } = await supabase.auth.getUser()
  if (!user) return new NextResponse("Unauthorized", { status: 401 })

  const { content, mode, scheduledAt } = await req.json()
  if (!content || typeof content !== "string") return new NextResponse("Missing content", { status: 400 })
  if (mode === "now") {
    try {
      const { accessToken, memberUrn } = await ensureFreshAccessToken(user.id)
      const result = await createTextPost({ accessToken, authorUrn: memberUrn, text: content })
      return NextResponse.json({ ok: true, result })
    } catch (e: any) {
      return new NextResponse(e.message || "Post failed", { status: 500 })
    }
  } else if (mode === "schedule") {
    if (!scheduledAt) return new NextResponse("Missing scheduledAt", { status: 400 })
    const when = new Date(scheduledAt)
    if (Number.isNaN(when.getTime())) return new NextResponse("Invalid datetime", { status: 400 })

    // Persist in DB for audit
    const { data: inserted, error } = await supabase
      .from("scheduled_posts")
      .insert({ user_id: user.id, content, scheduled_at: when.toISOString() })
      .select("id")
      .single()
    if (error) return new NextResponse(error.message, { status: 500 })

    // Add to Redis ZSET for scheduling
    const redis = getRedis()
    const key = "scheduled:linkedin:posts"
    await redis.zadd(key, { score: when.getTime(), member: JSON.stringify({ id: inserted.id, userId: user.id }) })

    return NextResponse.json({ ok: true, id: inserted.id })
  } else {
    return new NextResponse("Invalid mode", { status: 400 })
  }
}
